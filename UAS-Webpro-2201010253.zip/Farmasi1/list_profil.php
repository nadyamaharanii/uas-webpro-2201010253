<!DOCTYPE html>
<html>
<head>
    <title>Sistem Pendukung Keputusan - List Profil</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f2f2f2;
        }

        .navbar {
            background-color: #6c757d;
            color: #fff;
        }

        .navbar-brand {
            color: #fff;
            font-weight: bold;
        }

        .nav-link {
            color: #fff;
        }

        .content {
            padding: 20px;
        }

        .card {
            margin-bottom: 20px;
        }

        .footer {
            background-color: #333;
            color: #fff;
            padding: 10px;
            text-align: center;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark">
        <a class="navbar-brand" href="#">Sistem Pendukung Keputusan</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
            aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link" href="dashboard.php">
                        Dashboard
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="deteksi_penyakit.php">
                        Deteksi Penyakit
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="list_obat.php">
                        List Obat
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="list_profil.php">
                        List Profil
                    </a>
                </li>
            </ul>
        </div>
    </nav>

    <div class="container">
        <div class="content">
            <h1 class="text-center">List Profil</h1>
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Nama: John Doe</h5>
                    <h6 class="card-subtitle mb-2 text-muted">NIM: 1234567890</h6>
                    <p class="card-text">Semester: 5</p>
                    <p class="card-text">Jurusan: Farmasi</p>
                </div>
            </div>
        </div>
    </div>

    <footer class="footer">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <p>Kontak: 081234567890</p>
                </div>
                <div class="col-md-6">
                    <p class="text-right">Sistem Pendukung Keputusan - Farmasi</p>
                </div>
            </div>
        </div>
    </footer>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
