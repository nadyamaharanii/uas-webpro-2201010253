<!DOCTYPE html>
<html>
<head>
    <title>Sistem Pendukung Keputusan - Hasil Deteksi</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f2f2f2;
        }

        .navbar {
            background-color: #6c757d;
            color: #fff;
        }

        .navbar-brand {
            color: #fff;
            font-weight: bold;
        }

        .nav-link {
            color: #fff;
        }

        .content {
            padding: 20px;
        }

        .card {
            margin-bottom: 20px;
        }

        .btn-container {
            text-align: center;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark">
        <a class="navbar-brand" href="#">Sistem Pendukung Keputusan</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
            aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link" href="dashboard.php">
                        Dashboard
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="deteksi_penyakit.php">
                        Deteksi Penyakit
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="list_obat.php">
                        List Obat
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="list_profil.php">
                        List Profil
                    </a>
                </li>
            </ul>
        </div>
    </nav>

    <div class="container">
        <div class="content">
            <h1 class="text-center">Hasil Deteksi Penyakit</h1>
            <div class="card">
                <div class="card-body">
                    <?php
                    // Ambil gejala yang dipilih dari form deteksi
                    $gejala = $_POST['gejala'];

                    // Koneksi ke database
                    $servername = "localhost";
                    $username = "root";
                    $password = "";
                    $dbname = "sistem_pendukung_keputusan";

                    $conn = new mysqli($servername, $username, $password, $dbname);

                    // Periksa koneksi
                    if ($conn->connect_error) {
                        die("Koneksi gagal: " . $conn->connect_error);
                    }

                    // Query untuk mendapatkan penyakit berdasarkan gejala yang dipilih
                    $sql_penyakit = "SELECT penyakit.nama_penyakit, penyakit.deskripsi FROM gejala_penyakit
                                    INNER JOIN penyakit ON gejala_penyakit.id_penyakit = penyakit.id_penyakit
                                    WHERE gejala_penyakit.id_gejala IN (" . implode(',', $gejala) . ")";

                    $result_penyakit = $conn->query($sql_penyakit);

                    // Periksa apakah terdapat penyakit yang terdeteksi
                    if ($result_penyakit->num_rows > 0) {
                        echo '<h3>Penyakit yang Mungkin Terdeteksi:</h3>';
                        while ($row_penyakit = $result_penyakit->fetch_assoc()) {
                            echo '<div class="card">';
                            echo '<div class="card-body">';
                            echo '<h5 class="card-title">' . $row_penyakit["nama_penyakit"] . '</h5>';
                            echo '<p class="card-text">' . $row_penyakit["deskripsi"] . '</p>';
                            echo '</div>';
                            echo '</div>';
                        }

                        // Query untuk mendapatkan obat-obatan yang direkomendasikan untuk penyakit terdeteksi
// Query untuk mendapatkan obat-obatan yang direkomendasikan untuk penyakit terdeteksi
$sql_obat = "SELECT obat.nama_obat, obat.deskripsi FROM penyakit
             INNER JOIN obat ON penyakit.id_penyakit = obat.id_penyakit
             WHERE penyakit.id_penyakit IN (SELECT id_penyakit FROM gejala_penyakit
                                           WHERE id_gejala IN (" . implode(',', $gejala) . "))";

$result_obat = $conn->query($sql_obat);

// Periksa apakah terdapat obat yang direkomendasikan
if ($result_obat && $result_obat->num_rows > 0) {
                            echo '<h3>Obat yang Direkomendasikan:</h3>';
                            while ($row_obat = $result_obat->fetch_assoc()) {
                                echo '<div class="card">';
                                echo '<div class="card-body">';
                                echo '<h5 class="card-title">' . $row_obat["nama_obat"] . '</h5>';
                                echo '<p class="card-text">' . $row_obat["deskripsi"] . '</p>';
                                echo '</div>';
                                echo '</div>';
                            }
                        } else {
                            echo '<p>Tidak ditemukan obat yang direkomendasikan.</p>';
                        }
                    } else {
                        echo '<p>Tidak ditemukan penyakit berdasarkan gejala yang dipilih.</p>';
                    }

                    $conn->close();
                    ?>
                </div>
            </div>

            <div class="btn-container">
                <a href="list_obat.php" class="btn btn-primary">Lihat Daftar Obat</a>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
