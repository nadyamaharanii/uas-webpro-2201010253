<!DOCTYPE html>
<html>
<head>
    <title>Sistem Pendukung Keputusan - Dashboard</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f2f2f2;
        }

        .navbar {
            background-color: #6c757d;
            color: #fff;
        }

        .navbar-brand {
            color: #fff;
            font-weight: bold;
        }

        .nav-link {
            color: #fff;
        }

        .content {
            padding: 20px;
        }

        .logo {
            margin-bottom: 30px;
        }

        .logo img {
            width: 200px;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark">
        <a class="navbar-brand" href="#">Sistem Pendukung Keputusan</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
            aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link active" href="dashboard.php">
                        Dashboard
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="deteksi_penyakit.php">
                        Deteksi Penyakit
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="list_obat.php">
                        List Obat
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="list_profil.php">
                        List Profil
                    </a>
                </li>
            </ul>
        </div>
    </nav>

    <div class="container">
        <div class="content">
            <h1 class="text-center">Sistem Pendukung Keputusan</h1>
            <p class="text-center">Selamat datang di Sistem Pendukung Keputusan dalam bidang farmasi.</p>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
